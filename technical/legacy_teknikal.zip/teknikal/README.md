# Pipeline Teknikal

Folder ini memuat satu pipeline ringkas untuk data XAUUSD M5 yang sudah bersih
di view PostgreSQL `market.processed_m5`. Tidak ada pemisahan menjadi banyak
subfolder: persiapan data, feature engineering, training, dan evaluasi berada di
`pipeline.py`, sementara hasil default ditulis langsung ke folder ini.

## Isi pipeline

1. Membaca satu `source_key`, simbol, dan rentang waktu melalui transaksi
   PostgreSQL read-only.
2. Memvalidasi timestamp/OHLC, membuang duplikat timestamp, lalu mengurutkan data
   secara kronologis tanpa interpolation, forward fill, atau backfill.
3. Membuat fitur return, struktur candle, SMA, volatilitas, RSI, ATR, volume,
   spread, jam, dan hari. Semua fitur hanya memakai candle saat ini/masa lalu.
4. Membentuk target arah `SELL`/`NO_TRADE`/`BUY` serta future return.
5. Melakukan split train/test berdasarkan waktu, dengan embargo sebesar horizon
   target agar label train tidak memakai harga dari periode test.
6. Melatih classifier arah dan regressor return dengan histogram gradient
   boosting.
7. Menghitung F1 macro/weighted, confusion matrix, RMSE, MAE, dan MSE pada test
   set saja.

RMSE, MAE, dan MSE memakai future return desimal sebagai unit. File JSON juga
menyediakan RMSE dan MAE dalam basis points.

## Menjalankan

```powershell
uv run python -B -m teknikal.pipeline `
  --source-key metaquotes-demo-xauusd `
  --symbol XAUUSD `
  --start 2025-01-01T00:00:00Z `
  --end 2026-01-01T00:00:00Z
```

Gunakan `--no-trade-threshold 0.0001` untuk neutral zone satu basis point dan
`--horizon 1` untuk memprediksi satu candle M5 berikutnya. Nilai contoh harus
disesuaikan dengan source dan periode yang benar-benar tersedia di database.

## Hasil

- `model_teknikal.joblib`: classifier, regressor, urutan fitur, label, metadata.
- `metrik_evaluasi.json`: F1, confusion matrix, RMSE, MAE, MSE, dan batas waktu.
- `confusion_matrix.png`: visual confusion matrix test kronologis.
- `prediksi_test.csv`: actual versus prediction untuk audit setiap test row.

Menjalankan ulang pipeline pada folder output yang sama akan mengganti artefak
turunan sebelumnya; data sumber PostgreSQL tidak pernah diubah.

## XGBoost forecast harga dan sinyal September-Oktober 2026

Mode signal-forecast adalah workflow berbeda dari mode evaluate di atas. Ia
memakai XGBoost untuk memprediksi harga close harian terlebih dahulu. Sinyal
BUY, SELL, atau NO_TRADE adalah keputusan turunan dari perubahan harga yang
diprediksi dan biaya spread; model tidak langsung dilatih untuk mengeluarkan
kelas sinyal.

### Tujuan dan timeframe

Sumber awal tetap candle M5 XAUUSD, tetapi XGBoost forecast bekerja pada close
harian. Untuk setiap hari UTC, sistem memilih close dari candle M5 valid
terakhir pada hari itu. Nilai ini bukan rata-rata harga intraday dan hari tanpa
candle tidak diisi dengan data buatan.

Pemisahan waktu default adalah sebagai berikut:

| Periode | Peran | Boleh dilihat model? |
|---|---|---|
| 1 Januari 2016 sampai 31 Agustus 2026 | History dan training XGBoost | Ya |
| 1 September sampai 31 Oktober 2026 | Forecast out-of-sample | Tidak |
| Actual September-Oktober yang sudah tersedia | Ground truth untuk evaluasi | Tidak saat training maupun forecasting |

Batas query training bersifat eksklusif pada 1 September 2026 UTC. Artinya,
close 31 Agustus adalah harga terakhir yang diketahui model. Karena 31 Oktober
2026 adalah Sabtu, forecast business-day default berakhir pada Jumat,
30 Oktober. Sistem tetap membuat forecast untuk seluruh rentang tersebut,
meskipun actual masa depan belum tersedia.

### Data sumber

Mode ini memakai fungsi analytics.data.load_market_data dan membaca view
market.bar_latest untuk satu source UUID, simbol, dan timeframe M5.
market.bar_latest adalah versi candle terbaru per timestamp; bila broker
merevisi sebuah candle, versi lama tetap dapat diaudit pada tabel observasi,
sedangkan view ini memberi satu nilai canonical untuk analisis.

Data actual setelah 1 September dibaca melalui query terpisah. Nilainya tidak
pernah digabungkan ke data train, fitur lag, atau state recursive forecast.

### Fitur dan target XGBoost

XGBoost menggunakan 30 fitur numerik yang seluruhnya berasal dari close harian
masa lalu:

| Kelompok | Nama fitur | Arti |
|---|---|---|
| Lag harga | lag_1 sampai lag_30 | Close 1 sampai 30 hari trading sebelumnya |

Target setiap baris training adalah target_close, yaitu close hari berikutnya.
Contoh satu row:

    fitur: lag_1 = close kemarin, lag_2 = close dua hari lalu, ..., lag_30
    target: close hari ini

Parameter default model:

| Parameter | Nilai |
|---|---:|
| Objective | reg:squarederror |
| Jumlah tree | 400 |
| Kedalaman maksimum | 6 |
| Learning rate | 0,03 |
| Subsample | 0,9 |
| Colsample by tree | 0,9 |
| Random state | 42 |
| Worker | 1 |

Fitur RSI, MACD, SMA, ATR, candle body, volume, dan fitur M5 lain belum dipakai
oleh mode XGBoost ini. Fitur tersebut hanya ada pada mode evaluate lama.

### Cara data dibagi: train, forecast, dan test

Mode ini tidak memakai random split. Pembagiannya murni berdasarkan waktu:

    Data close harian 2016 sampai 31 Agustus
                 ↓
    Training XGBoost dengan 30 lag historis
                 ↓
    1 September sampai 31 Oktober
                 ↓
    Recursive forecast tanpa actual
                 ↓
    Cocokkan dengan actual yang tersedia untuk test/evaluasi

Setelah prediksi pertama, lag berikutnya memakai harga prediksi sebelumnya,
bukan close aktual September atau Oktober. Ini disebut recursive multi-step
forecast. Karena itu, error dapat menumpuk pada forecast yang semakin jauh;
dashboard dan metrik dibuat agar efek tersebut terlihat.

### Dari prediksi harga menjadi BUY, SELL, dan NO_TRADE

Untuk setiap tanggal forecast, sistem menghitung:

    predicted_move = forecast_close - reference_close

Reference close pertama adalah close 31 Agustus. Reference pada tanggal
berikutnya adalah forecast close sebelumnya. Spread price dihitung dari median
spread candle M5 pada 20 hari terakhir periode training, atau dapat diisi
manual dengan argumen spread-price-override.

Aturan sinyal:

    BUY       jika predicted_move > spread_price + minimum_edge
    SELL      jika predicted_move < -(spread_price + minimum_edge)
    NO_TRADE  jika predicted_move belum cukup untuk menutup spread

Jadi NO_TRADE bukan prediksi bahwa harga pasti diam. Artinya, model tidak
memperkirakan perubahan bersih yang cukup besar untuk melewati biaya spread.

### Perhitungan spread dan P/L

Satu spread dibebankan untuk setiap checkpoint BUY atau SELL. NO_TRADE tidak
dikenai spread. Sistem menyimpan dua jenis hasil:

- Predicted P/L: berdasarkan perubahan harga yang diprediksi.
- Realized P/L: berdasarkan perubahan actual setelah sinyal dibuat, jika actual
  tanggal tersebut sudah tersedia.

Keduanya dicatat dalam price unit XAUUSD dan kelipatan spread. Contoh net
realized +2,5 spread berarti gerakan aktual setelah spread setara keuntungan
2,5 kali spread yang diestimasi.

Ini bukan simulasi akun trading lengkap: belum ada lot, contract size, leverage,
komisi, swap, slippage, harga bid/ask eksekusi nyata, stop loss, atau take
profit. Hasil tidak boleh dianggap sebagai profit uang riil.

### Flow lengkap

    market.bar_latest M5
        -> valid close M5 terakhir per hari UTC
        -> close harian 2016 sampai 31 Agustus 2026
        -> 30 lag close
        -> XGBRegressor training
        -> forecast recursive 1 September sampai 31 Oktober
        -> predicted move dibanding spread
        -> BUY / SELL / NO_TRADE
        -> actual comparison hanya setelah prediction
        -> metrics JSON, CSV audit, dan dashboard interaktif

### Menjalankan

    uv run python -B -m teknikal.pipeline --mode signal-forecast `
      --source-id <uuid> `
      --symbol XAUUSD `
      --timeframe M5

Parameter penting:

| Parameter | Default | Fungsi |
|---|---|---|
| history-start | 2016-01-01T00:00:00Z | Awal data historis |
| forecast-start | 2026-09-01T00:00:00Z | Cutoff eksklusif training dan awal forecast |
| forecast-end | 2026-11-01T00:00:00Z | Akhir eksklusif forecast |
| lag-count | 30 | Jumlah close harian masa lalu |
| minimum-edge | 0,0 | Buffer tambahan di atas spread untuk membuka sinyal |
| spread-price-override | kosong | Spread manual bila spread database tidak tersedia |

### Output

Output default berada di teknikal/signal_forecast/:

- xgboost_price_forecaster.joblib: XGBoost, urutan 30 fitur lag, dan metadata.
- signal_forecast.csv: harga referensi/prediksi, sinyal, spread, actual
  comparison, dan predicted serta realized P/L.
- signal_forecast_metrics.json: MAE, MSE, RMSE, MAPE, confusion matrix, F1,
  jumlah sinyal, win/loss, spread terpakai, dan P/L.
- signal_forecast_dashboard.html: dashboard Plotly offline dengan garis history
  biru, forecast merah, actual hijau, checkpoint bulat, daily P/L, cumulative
  P/L, zoom, pan, hover, serta date range slider.

### Metrik evaluasi

Metrik harga dihitung hanya pada tanggal forecast yang memiliki actual:

- MAE: rata-rata nilai absolut selisih actual dan forecast.
- MSE: rata-rata kuadrat error; lebih sensitif terhadap error besar.
- RMSE: akar MSE, kembali ke satuan harga XAUUSD.
- MAPE: rata-rata error persentase terhadap actual.

Confusion matrix dan F1 membandingkan sinyal turunan forecast dengan kelas arah
actual yang memakai batas spread sama. Metrik ini menjawab apakah keputusan
BUY/SELL/NO_TRADE sesuai pergerakan actual setelah biaya spread, bukan apakah
model dilatih sebagai classifier.
