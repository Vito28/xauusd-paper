"""Leakage-safe XAUUSD price forecasting, signal derivation, and spread accounting.

This module extends the technical pipeline with a clearly separated workflow:

    market bars
    -> daily close
    -> XGBoost price forecast
    -> BUY, SELL, or NO_TRADE checkpoint
    -> price-unit profit/loss after one spread charge
    -> interactive Plotly dashboard and auditable JSON/CSV artifacts

The default model cutoff is 2026-09-01 UTC. Therefore, observations through
31 August 2026 may be used for training, while September and October actual
prices remain comparison-only. No lot size, leverage, commission, swap, or
currency conversion is applied; profit/loss is reported only in XAUUSD price
units.
"""

from __future__ import annotations

import argparse
import json
from datetime import UTC, datetime
from pathlib import Path
from typing import Any

import joblib
import numpy as np
import pandas as pd
from sklearn.metrics import confusion_matrix, f1_score

from analytics.analytics import (
    align_actual_and_forecast,
    calculate_forecast_metrics,
    forecast_recursively,
    prepare_daily_close,
    train_xgboost_forecaster,
)
from analytics.data import load_market_data

PACKAGE_ROOT = Path(__file__).resolve().parent
DEFAULT_REPORT_ROOT = PACKAGE_ROOT / "signal_forecast"
SIGNAL_LABELS = ("SELL", "NO_TRADE", "BUY")
DEFAULT_HISTORY_START = "2016-01-01T00:00:00Z"
DEFAULT_FORECAST_START = "2026-09-01T00:00:00Z"
DEFAULT_FORECAST_END = "2026-11-01T00:00:00Z"


def estimate_spread_price(
    history_bars: pd.DataFrame,
    *,
    lookback_days: int = 20,
    spread_price_override: float | None = None,
) -> float:
    """Estimate one leakage-safe spread cost from pre-forecast market bars.

    Args:
        history_bars: Intraday bars ending before the forecast cutoff.
        lookback_days: Trailing UTC days used for the median spread estimate.
        spread_price_override: Explicit positive price-unit spread when the
            database lacks spread_price or a fixed scenario is preferred.

    Returns:
        Median spread in XAUUSD price units. The same fixed estimate is charged
        once per BUY or SELL checkpoint; NO_TRADE has zero spread cost.
    """

    if spread_price_override is not None:
        if not np.isfinite(spread_price_override) or spread_price_override <= 0:
            raise ValueError("spread_price_override harus finite dan lebih besar dari nol")
        return float(spread_price_override)
    if lookback_days < 1:
        raise ValueError("lookback_days harus lebih besar dari nol")
    if "spread_price" not in history_bars.columns:
        raise ValueError("Kolom spread_price tidak tersedia; gunakan --spread-price-override")
    timestamps = pd.to_datetime(history_bars["open_time_utc"], utc=True, errors="coerce")
    spread = pd.to_numeric(history_bars["spread_price"], errors="coerce")
    valid = pd.DataFrame({"timestamp_utc": timestamps, "spread_price": spread})
    valid = valid.replace([np.inf, -np.inf], np.nan).dropna()
    valid = valid.loc[valid["spread_price"] > 0].sort_values("timestamp_utc")
    if valid.empty:
        raise ValueError("Spread price historis kosong; gunakan --spread-price-override")
    lower_bound = valid["timestamp_utc"].max() - pd.Timedelta(days=lookback_days)
    trailing = valid.loc[valid["timestamp_utc"] >= lower_bound, "spread_price"]
    return float(trailing.median())


def derive_price_signals(
    history: pd.DataFrame,
    forecast: pd.DataFrame,
    *,
    spread_price: float,
    minimum_edge: float = 0.0,
) -> pd.DataFrame:
    """Convert a price forecast into spread-aware BUY/SELL/NO_TRADE checkpoints.

    BUY requires the predicted upward move to exceed spread plus minimum_edge.
    SELL requires an equally large downward move. Smaller expected moves become
    NO_TRADE because their predicted gross movement does not cover trading cost.

    Returns:
        Forecast rows with reference price, predicted move and return, signal,
        spread cost, and predicted net price-unit profit/loss.
    """

    if not np.isfinite(spread_price) or spread_price <= 0:
        raise ValueError("spread_price harus finite dan lebih besar dari nol")
    if not np.isfinite(minimum_edge) or minimum_edge < 0:
        raise ValueError("minimum_edge tidak boleh negatif")
    required_history = {"timestamp_utc", "close"}
    required_forecast = {"timestamp_utc", "forecast_close"}
    if not required_history.issubset(history.columns):
        raise ValueError(f"History wajib memiliki kolom {sorted(required_history)}")
    if not required_forecast.issubset(forecast.columns):
        raise ValueError(f"Forecast wajib memiliki kolom {sorted(required_forecast)}")

    result = forecast[["timestamp_utc", "forecast_close"]].copy()
    result["timestamp_utc"] = pd.to_datetime(result["timestamp_utc"], utc=True)
    result["forecast_close"] = pd.to_numeric(result["forecast_close"], errors="raise")
    history_close = pd.to_numeric(history["close"], errors="coerce").dropna()
    if history_close.empty:
        raise ValueError("History tidak memiliki close valid")
    reference = np.r_[float(history_close.iloc[-1]), result["forecast_close"].iloc[:-1]]
    result["reference_close"] = reference
    result["predicted_move"] = result["forecast_close"] - result["reference_close"]
    result["predicted_return"] = result["predicted_move"] / result["reference_close"]
    threshold = spread_price + minimum_edge
    result["signal"] = np.select(
        [result["predicted_move"] < -threshold, result["predicted_move"] > threshold],
        ["SELL", "BUY"],
        default="NO_TRADE",
    )
    direction = result["signal"].map({"SELL": -1.0, "NO_TRADE": 0.0, "BUY": 1.0})
    result["predicted_gross_price_pnl"] = direction * result["predicted_move"]
    result["spread_cost"] = np.where(result["signal"] == "NO_TRADE", 0.0, spread_price)
    result["predicted_net_price_pnl"] = result["predicted_gross_price_pnl"] - result["spread_cost"]
    result.loc[result["signal"] == "NO_TRADE", "predicted_net_price_pnl"] = 0.0
    result["predicted_net_spreads"] = result["predicted_net_price_pnl"] / spread_price
    return result


def evaluate_signal_outcomes(
    history: pd.DataFrame,
    actual: pd.DataFrame,
    signals: pd.DataFrame,
    *,
    spread_price: float,
    minimum_edge: float = 0.0,
) -> pd.DataFrame:
    """Attach actual classes and realized price-unit P/L where ground truth exists.

    Actual prices are used only after signals have been created. Future dates
    without observations remain in the output with null realized fields.
    """

    actual_daily = actual[["timestamp_utc", "close"]].copy()
    actual_daily["timestamp_utc"] = pd.to_datetime(
        actual_daily["timestamp_utc"], utc=True, errors="coerce"
    )
    actual_daily["close"] = pd.to_numeric(actual_daily["close"], errors="coerce")
    actual_daily = actual_daily.dropna().sort_values("timestamp_utc")
    last_history = history[["timestamp_utc", "close"]].tail(1).copy()
    prices = pd.concat([last_history, actual_daily], ignore_index=True)
    prices = prices.sort_values("timestamp_utc").drop_duplicates("timestamp_utc", keep="last")
    prices["previous_actual_close"] = prices["close"].shift(1)
    prices["actual_move"] = prices["close"] - prices["previous_actual_close"]
    observed = prices.rename(columns={"close": "actual_close"})

    evaluated = signals.merge(
        observed[["timestamp_utc", "actual_close", "previous_actual_close", "actual_move"]],
        on="timestamp_utc",
        how="left",
        validate="one_to_one",
    )
    threshold = spread_price + minimum_edge
    evaluated["actual_class"] = np.select(
        [
            evaluated["actual_move"] < -threshold,
            evaluated["actual_move"] > threshold,
        ],
        ["SELL", "BUY"],
        default="NO_TRADE",
    )
    evaluated.loc[evaluated["actual_move"].isna(), "actual_class"] = None
    direction = evaluated["signal"].map({"SELL": -1.0, "NO_TRADE": 0.0, "BUY": 1.0})
    evaluated["realized_gross_price_pnl"] = direction * evaluated["actual_move"]
    evaluated["realized_net_price_pnl"] = (
        evaluated["realized_gross_price_pnl"] - evaluated["spread_cost"]
    )
    evaluated.loc[evaluated["signal"] == "NO_TRADE", "realized_net_price_pnl"] = 0.0
    evaluated.loc[evaluated["actual_move"].isna(), "realized_net_price_pnl"] = np.nan
    evaluated["realized_net_spreads"] = evaluated["realized_net_price_pnl"] / spread_price
    return evaluated


def calculate_signal_metrics(
    actual: pd.DataFrame,
    forecast: pd.DataFrame,
    evaluated_signals: pd.DataFrame,
    *,
    spread_price: float,
) -> dict[str, Any]:
    """Calculate price errors, signal quality, counts, and spread-only P/L.

    Profit/loss values are XAUUSD price differences, not account-currency
    profit. Lot size, contract size, leverage, commission, and swap are absent.
    """

    comparison = align_actual_and_forecast(actual, forecast)
    price_metrics = calculate_forecast_metrics(comparison)
    available = evaluated_signals.dropna(subset=["actual_class", "realized_net_price_pnl"])
    matrix = confusion_matrix(
        available["actual_class"],
        available["signal"],
        labels=list(SIGNAL_LABELS),
    )
    signal_counts = (
        evaluated_signals["signal"].value_counts().reindex(SIGNAL_LABELS, fill_value=0).astype(int)
    )
    traded = available.loc[available["signal"] != "NO_TRADE"]
    wins = int((traded["realized_net_price_pnl"] > 0).sum())
    losses = int((traded["realized_net_price_pnl"] < 0).sum())
    return {
        "price_forecast": price_metrics,
        "classification": {
            "labels": list(SIGNAL_LABELS),
            "confusion_matrix": matrix.tolist(),
            "f1_macro": float(
                f1_score(
                    available["actual_class"],
                    available["signal"],
                    labels=list(SIGNAL_LABELS),
                    average="macro",
                    zero_division=0,
                )
            ),
            "evaluated_observations": int(len(available)),
        },
        "signals": {label.lower(): int(signal_counts[label]) for label in SIGNAL_LABELS},
        "spread_accounting": {
            "unit": "XAUUSD price units; no lot/contract-size conversion",
            "spread_price_per_trade": float(spread_price),
            "evaluated_trades": int(len(traded)),
            "wins_after_spread": wins,
            "losses_after_spread": losses,
            "flat_after_spread": int(len(traded) - wins - losses),
            "win_rate_percent": float(wins / len(traded) * 100) if len(traded) else 0.0,
            "predicted_net_price_pnl_total": float(
                evaluated_signals["predicted_net_price_pnl"].sum()
            ),
            "predicted_net_spreads_total": float(evaluated_signals["predicted_net_spreads"].sum()),
            "realized_net_price_pnl_total_available": float(
                available["realized_net_price_pnl"].sum()
            ),
            "realized_net_spreads_total_available": float(available["realized_net_spreads"].sum()),
            "total_spread_charged_available": float(available["spread_cost"].sum()),
        },
    }


def create_signal_dashboard(
    history: pd.DataFrame,
    actual: pd.DataFrame,
    evaluated_signals: pd.DataFrame,
    metrics: dict[str, Any],
    output_path: Path,
    *,
    forecast_start: pd.Timestamp,
) -> Path:
    """Write an offline Plotly dashboard with price, checkpoints, and P/L.

    The red line is the recursive price forecast. BUY, SELL, and NO_TRADE
    checkpoints use green, orange, and gray circular markers. Users can zoom,
    pan, hover, autoscale, and use the date range slider.
    """

    from plotly import graph_objects as go
    from plotly.subplots import make_subplots

    figure = make_subplots(
        rows=3,
        cols=1,
        shared_xaxes=True,
        vertical_spacing=0.06,
        row_heights=[0.62, 0.18, 0.20],
        subplot_titles=(
            "XAUUSD price forecast and signal checkpoints",
            "Daily realized P/L after spread (available dates)",
            "Cumulative price-unit P/L",
        ),
    )
    figure.add_trace(
        go.Scatter(
            x=history["timestamp_utc"],
            y=history["close"],
            name="Historical / training",
            line={"color": "#2563eb", "width": 1.4},
        ),
        row=1,
        col=1,
    )
    figure.add_trace(
        go.Scatter(
            x=evaluated_signals["timestamp_utc"],
            y=evaluated_signals["forecast_close"],
            name="XGBoost price forecast",
            line={"color": "#dc2626", "width": 2.4},
            customdata=np.column_stack(
                [
                    evaluated_signals["signal"],
                    evaluated_signals["predicted_move"],
                    evaluated_signals["spread_cost"],
                    evaluated_signals["predicted_net_price_pnl"],
                ]
            ),
            hovertemplate=(
                "%{x|%Y-%m-%d}<br>Forecast: %{y:.3f}"
                "<br>Signal: %{customdata[0]}"
                "<br>Predicted move: %{customdata[1]:.3f}"
                "<br>Spread: %{customdata[2]:.3f}"
                "<br>Predicted net: %{customdata[3]:.3f}<extra></extra>"
            ),
        ),
        row=1,
        col=1,
    )
    figure.add_trace(
        go.Scatter(
            x=actual["timestamp_utc"],
            y=actual["close"],
            name="Actual comparison only",
            line={"color": "#16a34a", "width": 1.8},
        ),
        row=1,
        col=1,
    )
    marker_styles = {
        "BUY": ("#16a34a", 10),
        "SELL": ("#f97316", 10),
        "NO_TRADE": ("#6b7280", 6),
    }
    for label in SIGNAL_LABELS:
        selected = evaluated_signals.loc[evaluated_signals["signal"] == label]
        color, size = marker_styles[label]
        figure.add_trace(
            go.Scatter(
                x=selected["timestamp_utc"],
                y=selected["forecast_close"],
                name=label,
                mode="markers",
                marker={"color": color, "size": size, "symbol": "circle"},
                hovertemplate=f"%{{x|%Y-%m-%d}}<br>{label}<extra></extra>",
            ),
            row=1,
            col=1,
        )
    pnl_colors = np.where(
        evaluated_signals["realized_net_price_pnl"].fillna(0) >= 0,
        "#16a34a",
        "#dc2626",
    )
    figure.add_trace(
        go.Bar(
            x=evaluated_signals["timestamp_utc"],
            y=evaluated_signals["realized_net_price_pnl"],
            name="Realized net P/L",
            marker_color=pnl_colors,
        ),
        row=2,
        col=1,
    )
    figure.add_trace(
        go.Scatter(
            x=evaluated_signals["timestamp_utc"],
            y=evaluated_signals["predicted_net_price_pnl"].cumsum(),
            name="Cumulative predicted net",
            line={"color": "#7c3aed", "dash": "dot"},
        ),
        row=3,
        col=1,
    )
    figure.add_trace(
        go.Scatter(
            x=evaluated_signals["timestamp_utc"],
            y=evaluated_signals["realized_net_price_pnl"].fillna(0).cumsum(),
            name="Cumulative realized net (available)",
            line={"color": "#0891b2"},
        ),
        row=3,
        col=1,
    )
    figure.add_vline(
        x=forecast_start.timestamp() * 1000,
        line_dash="dash",
        line_color="#111827",
    )
    figure.update_xaxes(rangeslider={"visible": True}, row=3, col=1)
    figure.update_yaxes(title_text="Close", row=1, col=1)
    figure.update_yaxes(title_text="Price P/L", row=2, col=1)
    figure.update_yaxes(title_text="Cumulative", row=3, col=1)
    spread_metrics = metrics["spread_accounting"]
    realized_net = spread_metrics["realized_net_price_pnl_total_available"]
    figure.update_layout(
        title=(
            "XAUUSD September-October 2026 Signal Forecast"
            f" | Spread {spread_metrics['spread_price_per_trade']:.3f}"
            f" | Available realized net {realized_net:.3f}"
            f" | Win rate {spread_metrics['win_rate_percent']:.1f}%"
        ),
        template="plotly_white",
        height=1050,
        hovermode="x unified",
        dragmode="zoom",
        legend={"orientation": "h", "y": 1.05},
    )
    path = Path(output_path)
    if path.suffix.lower() != ".html":
        raise ValueError("Dashboard signal wajib berupa file HTML")
    path.parent.mkdir(parents=True, exist_ok=True)
    figure.write_html(path, include_plotlyjs=True, full_html=True)
    if not path.exists() or path.stat().st_size == 0:
        raise RuntimeError(f"Dashboard signal gagal dibuat: {path}")
    return path


def run_signal_forecast_pipeline(
    source_id: str,
    symbol: str,
    timeframe: str,
    *,
    history_start: str = DEFAULT_HISTORY_START,
    forecast_start: str = DEFAULT_FORECAST_START,
    forecast_end: str = DEFAULT_FORECAST_END,
    lag_count: int = 30,
    minimum_edge: float = 0.0,
    spread_price_override: float | None = None,
    random_state: int = 42,
    output_dir: Path = DEFAULT_REPORT_ROOT,
) -> tuple[dict[str, Any], dict[str, Path]]:
    """Train through August 2026 and forecast September through October.

    The history and actual queries are disjoint at forecast_start. Forecasts
    continue through the exclusive forecast_end boundary even when future
    actual data is unavailable. For the default dates, 31 October 2026 is a
    Saturday, so the final business-day checkpoint is Friday, 30 October.
    """

    start = _parse_utc(forecast_start, "forecast_start")
    end = _parse_utc(forecast_end, "forecast_end")
    if start >= end:
        raise ValueError("forecast_start harus lebih awal daripada forecast_end")
    cutoff = start.isoformat().replace("+00:00", "Z")
    end_text = end.isoformat().replace("+00:00", "Z")
    history_bars = load_market_data(source_id, symbol, timeframe, history_start, cutoff)
    actual_bars = load_market_data(source_id, symbol, timeframe, cutoff, end_text)
    history = prepare_daily_close(history_bars)
    actual = prepare_daily_close(actual_bars)
    spread_price = estimate_spread_price(history_bars, spread_price_override=spread_price_override)
    model, feature_columns = train_xgboost_forecaster(
        history,
        lag_count=lag_count,
        random_state=random_state,
        forecast_start=start,
    )
    forecast_dates = pd.date_range(start, end - pd.Timedelta(days=1), freq="B", tz="UTC")
    forecast = forecast_recursively(
        model,
        history,
        forecast_dates,
        lag_count=lag_count,
        forecast_start=start,
    )
    signals = derive_price_signals(
        history,
        forecast,
        spread_price=spread_price,
        minimum_edge=minimum_edge,
    )
    evaluated = evaluate_signal_outcomes(
        history,
        actual,
        signals,
        spread_price=spread_price,
        minimum_edge=minimum_edge,
    )
    metrics = calculate_signal_metrics(actual, forecast, evaluated, spread_price=spread_price)
    metadata: dict[str, Any] = {
        "created_at_utc": datetime.now(UTC).isoformat(),
        "source_id": source_id,
        "symbol": symbol,
        "timeframe": timeframe,
        "history_start": history_start,
        "training_end_exclusive": cutoff,
        "forecast_start": cutoff,
        "forecast_end_exclusive": end_text,
        "lag_count": lag_count,
        "minimum_edge_price": minimum_edge,
        "spread_price": spread_price,
        "random_state": random_state,
        "training_rows_daily": len(history),
        "forecast_rows": len(forecast),
        "actual_comparison_rows": len(actual),
        "feature_columns": feature_columns,
    }
    destination = Path(output_dir)
    destination.mkdir(parents=True, exist_ok=True)
    paths = {
        "model": destination / "xgboost_price_forecaster.joblib",
        "metrics": destination / "signal_forecast_metrics.json",
        "signals": destination / "signal_forecast.csv",
        "dashboard": destination / "signal_forecast_dashboard.html",
    }
    joblib.dump(
        {
            "model": model,
            "feature_columns": feature_columns,
            "metadata": metadata,
        },
        paths["model"],
    )
    evaluated.to_csv(paths["signals"], index=False)
    paths["metrics"].write_text(
        json.dumps({"metadata": metadata, **metrics}, indent=2, ensure_ascii=False),
        encoding="utf-8",
    )
    create_signal_dashboard(
        history,
        actual,
        evaluated,
        metrics,
        paths["dashboard"],
        forecast_start=start,
    )
    return metrics, paths


def build_parser() -> argparse.ArgumentParser:
    """Build a standalone CLI for September-October signal forecasting."""

    parser = argparse.ArgumentParser(
        description=(
            "Train XGBoost through August 2026, forecast September-October, "
            "derive spread-aware signals, and create an interactive dashboard."
        )
    )
    parser.add_argument("--source-id", required=True)
    parser.add_argument("--symbol", default="XAUUSD")
    parser.add_argument("--timeframe", default="M5")
    parser.add_argument("--history-start", default=DEFAULT_HISTORY_START)
    parser.add_argument("--forecast-start", default=DEFAULT_FORECAST_START)
    parser.add_argument("--forecast-end", default=DEFAULT_FORECAST_END)
    parser.add_argument("--lag-count", type=int, default=30)
    parser.add_argument("--minimum-edge", type=float, default=0.0)
    parser.add_argument("--spread-price-override", type=float)
    parser.add_argument("--random-state", type=int, default=42)
    parser.add_argument("--output-dir", type=Path, default=DEFAULT_REPORT_ROOT)
    return parser


def main() -> None:
    """Run signal forecasting and print metrics plus artifact locations."""

    arguments = build_parser().parse_args()
    metrics, paths = run_signal_forecast_pipeline(
        arguments.source_id,
        arguments.symbol,
        arguments.timeframe,
        history_start=arguments.history_start,
        forecast_start=arguments.forecast_start,
        forecast_end=arguments.forecast_end,
        lag_count=arguments.lag_count,
        minimum_edge=arguments.minimum_edge,
        spread_price_override=arguments.spread_price_override,
        random_state=arguments.random_state,
        output_dir=arguments.output_dir,
    )
    print(json.dumps(metrics, indent=2, ensure_ascii=False))
    for name, path in paths.items():
        print(f"{name}: {path}")


def _parse_utc(value: str, name: str) -> pd.Timestamp:
    """Parse one timezone-aware timestamp and normalize it to UTC."""

    parsed = pd.Timestamp(value)
    if parsed.tzinfo is None:
        raise ValueError(f"{name} wajib memiliki timezone")
    return parsed.tz_convert("UTC")


if __name__ == "__main__":
    main()
