"""Technical machine-learning pipeline for clean XAUUSD M5 observations.

The package keeps data preparation, feature engineering, chronological model
training, and evaluation in one compact folder. It consumes the read-only
``market.processed_m5`` PostgreSQL view and never changes collector data.
"""
