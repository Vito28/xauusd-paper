"""Train/evaluate M5 models or run the daily XGBoost signal forecast.

Data flow:
    ``market.processed_m5``
    -> deterministic preparation
    -> backward-looking technical features
    -> purged chronological train/test split
    -> direction classification and future-return regression
    -> model, predictions, JSON metrics, and confusion-matrix artifacts

All generated artifacts are written directly into ``teknikal/`` by default so
the technical stage stays easy to inspect. The module reads PostgreSQL through
an explicit read-only transaction and does not place trades or modify source
observations.

Signal-forecast mode delegates to teknikal.signal_forecast. It trains through
31 August 2026, forecasts September through October, derives
BUY/SELL/NO_TRADE from predicted price movement, and reports price-unit
profit/loss after spread without applying a lot size.
"""

from __future__ import annotations

import argparse
import json
from collections.abc import Sequence
from dataclasses import dataclass
from datetime import UTC, datetime
from pathlib import Path
from typing import Any

import joblib
import matplotlib

matplotlib.use("Agg")

import matplotlib.pyplot as plt
import numpy as np
import pandas as pd
from sklearn.compose import TransformedTargetRegressor
from sklearn.ensemble import HistGradientBoostingClassifier, HistGradientBoostingRegressor
from sklearn.impute import SimpleImputer
from sklearn.metrics import (
    ConfusionMatrixDisplay,
    confusion_matrix,
    f1_score,
    mean_absolute_error,
    mean_squared_error,
)
from sklearn.pipeline import Pipeline
from sklearn.preprocessing import StandardScaler
from sqlalchemy import Engine, text

from database.session import get_engine

PACKAGE_ROOT = Path(__file__).resolve().parent
CLASS_LABELS = ("SELL", "NO_TRADE", "BUY")
REQUIRED_COLUMNS = (
    "open_time_utc",
    "open",
    "high",
    "low",
    "close",
    "tick_volume",
)


@dataclass(frozen=True, slots=True)
class DatasetSplit:
    """Chronological train/test arrays with an embargo between both periods.

    The embargo contains ``horizon`` observations. It prevents a training
    target from using a future price that belongs to the test period.
    """

    x_train: pd.DataFrame
    x_test: pd.DataFrame
    y_train_class: pd.Series
    y_test_class: pd.Series
    y_train_return: pd.Series
    y_test_return: pd.Series
    train_times: pd.Series
    test_times: pd.Series


@dataclass(frozen=True, slots=True)
class TrainedModels:
    """Fitted classification and regression pipelines."""

    classifier: Pipeline
    regressor: TransformedTargetRegressor


def load_clean_data(
    source_key: str,
    symbol: str,
    start: str,
    end: str,
    *,
    engine: Engine | None = None,
) -> pd.DataFrame:
    """Load one clean broker/symbol interval from ``market.processed_m5``.

    Args:
        source_key: Stable broker data-source key. Sources are never mixed.
        symbol: Canonical or exact broker symbol.
        start: Inclusive timezone-aware timestamp.
        end: Exclusive timezone-aware timestamp.
        engine: Optional SQLAlchemy engine used by isolated tests.

    Returns:
        Chronologically ordered M5 observations from the research view.

    Raises:
        ValueError: If identifiers or timestamps are invalid, or no rows exist.
        RuntimeError: If the read-only database query fails.
    """

    if not source_key.strip() or not symbol.strip():
        raise ValueError("source_key dan symbol wajib diisi")
    start_utc = _parse_utc(start, "start")
    end_utc = _parse_utc(end, "end")
    if start_utc >= end_utc:
        raise ValueError("start harus lebih awal daripada end")

    active_engine = engine or get_engine()
    owns_engine = engine is None
    try:
        with active_engine.connect() as connection:
            transaction = connection.begin()
            try:
                connection.execute(text("SET TRANSACTION READ ONLY"))
                frame = pd.read_sql_query(
                    text(
                        """
                        SELECT open_time_utc, open, high, low, close,
                               tick_volume, real_volume, native_spread_price,
                               spread_mean, spread_std, tick_count,
                               bar_quality_status
                        FROM market.processed_m5
                        WHERE source_key = :source_key
                          AND (dataset_symbol = :symbol OR actual_symbol = :symbol)
                          AND open_time_utc >= :start_utc
                          AND open_time_utc < :end_utc
                        ORDER BY open_time_utc
                        """
                    ),
                    connection,
                    params={
                        "source_key": source_key.strip(),
                        "symbol": symbol.strip(),
                        "start_utc": start_utc.to_pydatetime(),
                        "end_utc": end_utc.to_pydatetime(),
                    },
                )
                transaction.commit()
            except Exception:
                transaction.rollback()
                raise
    except Exception as exc:
        raise RuntimeError(
            "Gagal membaca market.processed_m5; periksa koneksi dan migration database."
        ) from exc
    finally:
        if owns_engine:
            active_engine.dispose()

    if frame.empty:
        raise ValueError("Data clean kosong untuk source, symbol, dan rentang tersebut")
    return frame


def prepare_data(frame: pd.DataFrame) -> pd.DataFrame:
    """Validate, type-cast, de-duplicate, and order clean OHLCV observations.

    No interpolation, forward fill, backfill, or outlier deletion is performed.
    Rows that violate timestamp, finite-price, positivity, or OHLC invariants
    are excluded because they cannot be valid model inputs.

    Args:
        frame: Clean M5 observations, normally from ``load_clean_data``.

    Returns:
        A new chronological frame with valid unique candle timestamps.
    """

    missing = [column for column in REQUIRED_COLUMNS if column not in frame.columns]
    if missing:
        raise ValueError(f"Kolom data wajib tidak ditemukan: {missing}")

    prepared = frame.copy(deep=True)
    prepared["open_time_utc"] = pd.to_datetime(prepared["open_time_utc"], utc=True, errors="coerce")
    numeric_columns = [column for column in prepared.columns if column != "open_time_utc"]
    for column in numeric_columns:
        if column != "bar_quality_status":
            prepared[column] = pd.to_numeric(prepared[column], errors="coerce")

    price_columns = ["open", "high", "low", "close"]
    finite_prices = np.isfinite(prepared[price_columns]).all(axis=1)
    valid_prices = (prepared[price_columns] > 0).all(axis=1)
    valid_ohlc = (prepared["high"] >= prepared[["open", "close", "low"]].max(axis=1)) & (
        prepared["low"] <= prepared[["open", "close", "high"]].min(axis=1)
    )
    prepared = prepared.loc[
        prepared["open_time_utc"].notna() & finite_prices & valid_prices & valid_ohlc
    ]
    prepared = (
        prepared.sort_values("open_time_utc")
        .drop_duplicates(subset=["open_time_utc"], keep="last")
        .reset_index(drop=True)
    )
    if len(prepared) < 100:
        raise ValueError("Minimal 100 candle valid diperlukan untuk pipeline teknikal")
    return prepared


def engineer_features(
    frame: pd.DataFrame,
    *,
    horizon: int = 1,
    no_trade_threshold: float = 0.0001,
) -> tuple[pd.DataFrame, list[str]]:
    """Create backward-looking technical predictors and future targets.

    Every predictor at time ``t`` uses only the candle at ``t`` or earlier.
    The regression target is the decimal close-to-close return after
    ``horizon`` M5 bars. Classification maps that return to ``SELL``,
    ``NO_TRADE``, or ``BUY`` using ``no_trade_threshold``.

    Args:
        frame: Prepared chronological OHLCV observations.
        horizon: Number of M5 bars between decision time and target close.
        no_trade_threshold: Absolute decimal return defining the neutral zone.

    Returns:
        A model-ready frame and the exact predictor-column list.

    Raises:
        ValueError: If parameters are invalid or too few usable rows remain.
    """

    if horizon <= 0:
        raise ValueError("horizon harus lebih besar dari nol")
    if no_trade_threshold < 0:
        raise ValueError("no_trade_threshold tidak boleh negatif")

    data = frame.copy(deep=True)
    close = data["close"].astype(float)
    high = data["high"].astype(float)
    low = data["low"].astype(float)
    open_price = data["open"].astype(float)
    volume = data["tick_volume"].astype(float)
    returns = close.pct_change(fill_method=None)
    previous_close = close.shift(1)
    true_range = pd.concat(
        [high - low, (high - previous_close).abs(), (low - previous_close).abs()], axis=1
    ).max(axis=1)

    data["return_1"] = returns
    data["return_3"] = close.pct_change(3, fill_method=None)
    data["return_6"] = close.pct_change(6, fill_method=None)
    data["range_pct"] = (high - low) / close
    data["body_pct"] = (close - open_price) / open_price
    data["upper_wick_pct"] = (high - pd.concat([open_price, close], axis=1).max(axis=1)) / close
    data["lower_wick_pct"] = (pd.concat([open_price, close], axis=1).min(axis=1) - low) / close

    feature_columns = [
        "return_1",
        "return_3",
        "return_6",
        "range_pct",
        "body_pct",
        "upper_wick_pct",
        "lower_wick_pct",
    ]
    for window in (5, 12, 24):
        name = f"close_vs_sma_{window}"
        data[name] = close / close.rolling(window, min_periods=window).mean() - 1
        feature_columns.append(name)

    data["volatility_12"] = returns.rolling(12, min_periods=12).std()
    data["volatility_24"] = returns.rolling(24, min_periods=24).std()
    delta = close.diff()
    average_gain = delta.clip(lower=0).rolling(14, min_periods=14).mean()
    average_loss = -delta.clip(upper=0).rolling(14, min_periods=14).mean()
    relative_strength = average_gain / average_loss.replace(0, np.nan)
    data["rsi_14"] = 100 - (100 / (1 + relative_strength))
    data["atr_pct_14"] = true_range.rolling(14, min_periods=14).mean() / close
    data["tick_volume_change"] = volume.pct_change(fill_method=None)
    volume_mean = volume.rolling(24, min_periods=24).mean()
    volume_std = volume.rolling(24, min_periods=24).std().replace(0, np.nan)
    data["tick_volume_zscore_24"] = (volume - volume_mean) / volume_std
    feature_columns.extend(
        [
            "volatility_12",
            "volatility_24",
            "rsi_14",
            "atr_pct_14",
            "tick_volume_change",
            "tick_volume_zscore_24",
        ]
    )

    spread = pd.Series(np.nan, index=data.index, dtype=float)
    if "spread_mean" in data:
        spread = pd.to_numeric(data["spread_mean"], errors="coerce")
    if "native_spread_price" in data:
        spread = spread.fillna(pd.to_numeric(data["native_spread_price"], errors="coerce"))
    data["spread_pct"] = spread / close
    feature_columns.append("spread_pct")

    hours = data["open_time_utc"].dt.hour + data["open_time_utc"].dt.minute / 60
    weekdays = data["open_time_utc"].dt.dayofweek
    data["hour_sin"] = np.sin(2 * np.pi * hours / 24)
    data["hour_cos"] = np.cos(2 * np.pi * hours / 24)
    data["weekday_sin"] = np.sin(2 * np.pi * weekdays / 7)
    data["weekday_cos"] = np.cos(2 * np.pi * weekdays / 7)
    feature_columns.extend(["hour_sin", "hour_cos", "weekday_sin", "weekday_cos"])

    data[feature_columns] = data[feature_columns].replace([np.inf, -np.inf], np.nan)
    feature_columns = [column for column in feature_columns if data[column].notna().any()]
    future_close = close.shift(-horizon)
    data["target_return"] = future_close / close - 1
    data["target_class"] = np.select(
        [
            data["target_return"] < -no_trade_threshold,
            data["target_return"] > no_trade_threshold,
        ],
        ["SELL", "BUY"],
        default="NO_TRADE",
    )
    data.loc[future_close.isna(), "target_class"] = np.nan
    data = data.dropna(subset=["target_return", "target_class"]).reset_index(drop=True)
    if len(data) < 100:
        raise ValueError("Minimal 100 baris model-ready diperlukan setelah feature engineering")
    if len(feature_columns) < 5:
        raise ValueError("Feature numerik yang tersedia terlalu sedikit")
    return data, feature_columns


def chronological_split(
    frame: pd.DataFrame,
    feature_columns: Sequence[str],
    *,
    train_fraction: float = 0.8,
    horizon: int = 1,
) -> DatasetSplit:
    """Split model data chronologically and purge the target-overlap boundary.

    Args:
        frame: Feature and target frame from ``engineer_features``.
        feature_columns: Predictor columns only.
        train_fraction: Fraction assigned to the earlier training interval.
        horizon: Target horizon used to create an equally sized embargo.

    Returns:
        Typed train/test arrays that preserve temporal order.
    """

    if not 0.5 <= train_fraction < 1:
        raise ValueError("train_fraction harus berada pada rentang [0.5, 1)")
    if horizon <= 0:
        raise ValueError("horizon harus lebih besar dari nol")
    missing = [column for column in feature_columns if column not in frame.columns]
    if missing:
        raise ValueError(f"Feature tidak ditemukan: {missing}")

    split_index = int(len(frame) * train_fraction)
    train_end = split_index - horizon
    if train_end < 50 or len(frame) - split_index < 30:
        raise ValueError("Split membutuhkan minimal 50 train dan 30 test rows")
    train = frame.iloc[:train_end]
    test = frame.iloc[split_index:]
    if train["target_class"].nunique() < 2:
        raise ValueError("Data train harus memiliki minimal dua kelas target")

    return DatasetSplit(
        x_train=train[list(feature_columns)],
        x_test=test[list(feature_columns)],
        y_train_class=train["target_class"].astype(str),
        y_test_class=test["target_class"].astype(str),
        y_train_return=train["target_return"].astype(float),
        y_test_return=test["target_return"].astype(float),
        train_times=train["open_time_utc"].reset_index(drop=True),
        test_times=test["open_time_utc"].reset_index(drop=True),
    )


def train_models(
    split: DatasetSplit,
    *,
    iterations: int = 200,
    random_state: int = 42,
) -> TrainedModels:
    """Fit scalable histogram-gradient classification and regression models.

    Args:
        split: Chronological train/test arrays.
        iterations: Maximum boosting iterations for each model.
        random_state: Reproducible estimator seed.

    Returns:
        Fitted preprocessing and estimator pipelines.
    """

    if iterations <= 0:
        raise ValueError("iterations harus lebih besar dari nol")
    classifier = Pipeline(
        steps=[
            ("imputer", SimpleImputer(strategy="median")),
            ("scaler", StandardScaler()),
            (
                "model",
                HistGradientBoostingClassifier(
                    max_iter=iterations,
                    learning_rate=0.05,
                    max_leaf_nodes=31,
                    l2_regularization=1.0,
                    class_weight="balanced",
                    random_state=random_state,
                ),
            ),
        ]
    )
    base_regressor = Pipeline(
        steps=[
            ("imputer", SimpleImputer(strategy="median")),
            ("scaler", StandardScaler()),
            (
                "model",
                HistGradientBoostingRegressor(
                    max_iter=iterations,
                    learning_rate=0.05,
                    max_leaf_nodes=31,
                    l2_regularization=1.0,
                    random_state=random_state,
                ),
            ),
        ]
    )
    regressor = TransformedTargetRegressor(
        regressor=base_regressor,
        transformer=StandardScaler(),
    )
    classifier.fit(split.x_train, split.y_train_class)
    regressor.fit(split.x_train, split.y_train_return)
    return TrainedModels(classifier=classifier, regressor=regressor)


def evaluate_models(
    models: TrainedModels,
    split: DatasetSplit,
) -> tuple[dict[str, Any], pd.DataFrame, np.ndarray]:
    """Calculate F1, confusion matrix, RMSE, MAE, and MSE on test data.

    Regression metrics use decimal future return as the unit. MAE and RMSE are
    also reported in basis points for easier interpretation.

    Args:
        models: Fitted direction and return models.
        split: The same chronological split used for training.

    Returns:
        JSON-compatible metrics, row-level test predictions, and confusion
        matrix values ordered as SELL, NO_TRADE, BUY.
    """

    predicted_class = models.classifier.predict(split.x_test)
    predicted_return = models.regressor.predict(split.x_test)
    mse = float(mean_squared_error(split.y_test_return, predicted_return))
    mae = float(mean_absolute_error(split.y_test_return, predicted_return))
    rmse = float(np.sqrt(mse))
    matrix = confusion_matrix(
        split.y_test_class,
        predicted_class,
        labels=list(CLASS_LABELS),
    )
    metrics: dict[str, Any] = {
        "classification": {
            "f1_macro": float(
                f1_score(
                    split.y_test_class,
                    predicted_class,
                    labels=list(CLASS_LABELS),
                    average="macro",
                    zero_division=0,
                )
            ),
            "f1_weighted": float(
                f1_score(
                    split.y_test_class,
                    predicted_class,
                    labels=list(CLASS_LABELS),
                    average="weighted",
                    zero_division=0,
                )
            ),
            "labels": list(CLASS_LABELS),
            "confusion_matrix": matrix.tolist(),
        },
        "regression": {
            "target": "future_return_decimal",
            "rmse": rmse,
            "mae": mae,
            "mse": mse,
            "rmse_basis_points": rmse * 10_000,
            "mae_basis_points": mae * 10_000,
        },
    }
    predictions = pd.DataFrame(
        {
            "open_time_utc": split.test_times,
            "actual_class": split.y_test_class.reset_index(drop=True),
            "predicted_class": predicted_class,
            "actual_return": split.y_test_return.reset_index(drop=True),
            "predicted_return": predicted_return,
        }
    )
    return metrics, predictions, matrix


def save_artifacts(
    models: TrainedModels,
    metrics: dict[str, Any],
    predictions: pd.DataFrame,
    matrix: np.ndarray,
    feature_columns: Sequence[str],
    metadata: dict[str, Any],
    *,
    output_dir: Path = PACKAGE_ROOT,
) -> dict[str, Path]:
    """Persist the fitted models and all requested evaluation artifacts.

    Args:
        models: Fitted direction and return models.
        metrics: Evaluation values returned by ``evaluate_models``.
        predictions: Row-level test predictions.
        matrix: Confusion matrix ordered by ``CLASS_LABELS``.
        feature_columns: Ordered predictors required at inference time.
        metadata: Run parameters and row/time boundaries.
        output_dir: Destination; defaults directly to ``teknikal/``.

    Returns:
        Mapping of artifact names to created paths.
    """

    destination = Path(output_dir)
    destination.mkdir(parents=True, exist_ok=True)
    paths = {
        "model": destination / "model_teknikal.joblib",
        "metrics": destination / "metrik_evaluasi.json",
        "predictions": destination / "prediksi_test.csv",
        "confusion_matrix": destination / "confusion_matrix.png",
    }
    artifact = {
        "classifier": models.classifier,
        "regressor": models.regressor,
        "feature_columns": list(feature_columns),
        "class_labels": list(CLASS_LABELS),
        "metadata": metadata,
    }
    joblib.dump(artifact, paths["model"])
    predictions.to_csv(paths["predictions"], index=False)
    payload = {"metadata": metadata, **metrics}
    paths["metrics"].write_text(json.dumps(payload, indent=2, ensure_ascii=False), encoding="utf-8")

    figure, axis = plt.subplots(figsize=(8, 6))
    ConfusionMatrixDisplay(
        confusion_matrix=matrix,
        display_labels=list(CLASS_LABELS),
    ).plot(ax=axis, colorbar=False, cmap="Blues")
    axis.set_title("Confusion Matrix - Test Kronologis")
    figure.tight_layout()
    figure.savefig(paths["confusion_matrix"], dpi=150, bbox_inches="tight")
    plt.close(figure)
    return paths


def run_pipeline(
    source_key: str,
    symbol: str,
    start: str,
    end: str,
    *,
    horizon: int = 1,
    no_trade_threshold: float = 0.0001,
    train_fraction: float = 0.8,
    iterations: int = 200,
    random_state: int = 42,
    output_dir: Path = PACKAGE_ROOT,
) -> tuple[dict[str, Any], dict[str, Path]]:
    """Execute data preparation, feature engineering, training, and evaluation.

    Args:
        source_key: Stable broker source key.
        symbol: Canonical or exact broker symbol.
        start: Inclusive timezone-aware query timestamp.
        end: Exclusive timezone-aware query timestamp.
        horizon: Number of M5 bars predicted ahead.
        no_trade_threshold: Neutral-zone return in decimal form.
        train_fraction: Earlier chronological fraction used for training.
        iterations: Maximum boosting iterations per model.
        random_state: Reproducible estimator seed.
        output_dir: Artifact directory, normally ``teknikal/``.

    Returns:
        Evaluation metrics and created artifact paths.
    """

    raw = load_clean_data(source_key, symbol, start, end)
    prepared = prepare_data(raw)
    model_frame, feature_columns = engineer_features(
        prepared,
        horizon=horizon,
        no_trade_threshold=no_trade_threshold,
    )
    split = chronological_split(
        model_frame,
        feature_columns,
        train_fraction=train_fraction,
        horizon=horizon,
    )
    models = train_models(split, iterations=iterations, random_state=random_state)
    metrics, predictions, matrix = evaluate_models(models, split)
    metadata: dict[str, Any] = {
        "created_at_utc": datetime.now(UTC).isoformat(),
        "source_key": source_key,
        "symbol": symbol,
        "requested_start": start,
        "requested_end": end,
        "horizon_bars": horizon,
        "no_trade_threshold": no_trade_threshold,
        "train_fraction": train_fraction,
        "random_state": random_state,
        "raw_rows": len(raw),
        "prepared_rows": len(prepared),
        "model_ready_rows": len(model_frame),
        "train_rows": len(split.x_train),
        "test_rows": len(split.x_test),
        "train_start_utc": split.train_times.iloc[0].isoformat(),
        "train_end_utc": split.train_times.iloc[-1].isoformat(),
        "test_start_utc": split.test_times.iloc[0].isoformat(),
        "test_end_utc": split.test_times.iloc[-1].isoformat(),
        "feature_columns": feature_columns,
    }
    paths = save_artifacts(
        models,
        metrics,
        predictions,
        matrix,
        feature_columns,
        metadata,
        output_dir=output_dir,
    )
    return metrics, paths


def build_parser() -> argparse.ArgumentParser:
    """Build the evaluation and signal-forecast command-line interface."""

    parser = argparse.ArgumentParser(
        description=(
            "Prepare clean M5 data, engineer features, train direction/return models, "
            "and calculate F1, confusion matrix, RMSE, MAE, and MSE."
        )
    )
    parser.add_argument(
        "--mode",
        choices=("evaluate", "signal-forecast"),
        default="evaluate",
        help="Existing M5 evaluation or September-October price/signal forecast.",
    )
    parser.add_argument("--source-key", help="Stable broker source key for evaluate mode.")
    parser.add_argument("--source-id", help="Database source UUID for signal-forecast mode.")
    parser.add_argument("--symbol", default="XAUUSD", help="Canonical or exact broker symbol.")
    parser.add_argument("--timeframe", default="M5")
    parser.add_argument("--start", help="Inclusive timestamp for evaluate mode.")
    parser.add_argument("--end", help="Exclusive timestamp for evaluate mode.")
    parser.add_argument("--horizon", type=int, default=1, help="M5 bars predicted ahead.")
    parser.add_argument(
        "--no-trade-threshold",
        type=float,
        default=0.0001,
        help="Absolute future-return neutral zone; 0.0001 equals one basis point.",
    )
    parser.add_argument("--train-fraction", type=float, default=0.8)
    parser.add_argument("--iterations", type=int, default=200)
    parser.add_argument("--random-state", type=int, default=42)
    parser.add_argument("--output-dir", type=Path, default=PACKAGE_ROOT)
    parser.add_argument("--history-start", default="2016-01-01T00:00:00Z")
    parser.add_argument("--forecast-start", default="2026-09-01T00:00:00Z")
    parser.add_argument("--forecast-end", default="2026-11-01T00:00:00Z")
    parser.add_argument("--lag-count", type=int, default=30)
    parser.add_argument("--minimum-edge", type=float, default=0.0)
    parser.add_argument("--spread-price-override", type=float)
    parser.add_argument(
        "--signal-output-dir",
        type=Path,
        default=PACKAGE_ROOT / "signal_forecast",
    )
    return parser


def main() -> None:
    """Run classic evaluation or the leakage-safe signal forecast."""

    parser = build_parser()
    arguments = parser.parse_args()
    if arguments.mode == "signal-forecast":
        if not arguments.source_id:
            parser.error("--source-id wajib untuk --mode signal-forecast")
        from teknikal.signal_forecast import run_signal_forecast_pipeline

        metrics, paths = run_signal_forecast_pipeline(
            arguments.source_id,
            arguments.symbol,
            arguments.timeframe,
            history_start=arguments.history_start,
            forecast_start=arguments.forecast_start,
            forecast_end=arguments.forecast_end,
            lag_count=arguments.lag_count,
            minimum_edge=arguments.minimum_edge,
            spread_price_override=arguments.spread_price_override,
            random_state=arguments.random_state,
            output_dir=arguments.signal_output_dir,
        )
        print(json.dumps(metrics, indent=2, ensure_ascii=False))
        for name, path in paths.items():
            print(f"{name}: {path}")
        return
    if not arguments.source_key or not arguments.start or not arguments.end:
        parser.error("--source-key, --start, dan --end wajib untuk --mode evaluate")
    metrics, paths = run_pipeline(
        arguments.source_key,
        arguments.symbol,
        arguments.start,
        arguments.end,
        horizon=arguments.horizon,
        no_trade_threshold=arguments.no_trade_threshold,
        train_fraction=arguments.train_fraction,
        iterations=arguments.iterations,
        random_state=arguments.random_state,
        output_dir=arguments.output_dir,
    )
    print(json.dumps(metrics, indent=2, ensure_ascii=False))
    for name, path in paths.items():
        print(f"{name}: {path}")


def _parse_utc(value: str, name: str) -> pd.Timestamp:
    try:
        parsed = pd.Timestamp(value)
    except ValueError as exc:
        raise ValueError(f"{name} tidak valid: {value!r}") from exc
    if parsed.tzinfo is None:
        raise ValueError(f"{name} wajib memiliki timezone")
    return parsed.tz_convert("UTC")


if __name__ == "__main__":
    main()
