"""Tests for the compact technical preparation, training, and evaluation pipeline."""

from __future__ import annotations

from datetime import UTC, datetime
from pathlib import Path

import numpy as np
import pandas as pd

from teknikal.pipeline import (
    chronological_split,
    engineer_features,
    evaluate_models,
    prepare_data,
    save_artifacts,
    train_models,
)
from teknikal.signal_forecast import (
    calculate_signal_metrics,
    create_signal_dashboard,
    derive_price_signals,
    estimate_spread_price,
    evaluate_signal_outcomes,
)


def synthetic_market_frame(rows: int = 420) -> pd.DataFrame:
    """Build deterministic valid OHLCV data with rising and falling regimes."""

    index = np.arange(rows, dtype=float)
    increments = 0.35 * np.sin(index / 3) + 0.15 * np.sin(index / 11)
    close = 2_600 + np.cumsum(increments)
    open_price = np.r_[close[0], close[:-1]]
    high = np.maximum(open_price, close) + 0.2
    low = np.minimum(open_price, close) - 0.2
    return pd.DataFrame(
        {
            "open_time_utc": pd.date_range(
                datetime(2025, 1, 1, tzinfo=UTC), periods=rows, freq="5min"
            ),
            "open": open_price,
            "high": high,
            "low": low,
            "close": close,
            "tick_volume": 100 + (index % 37),
            "real_volume": np.zeros(rows),
            "native_spread_price": np.full(rows, 0.2),
            "spread_mean": np.where(index % 2 == 0, 0.18, np.nan),
            "spread_std": np.full(rows, 0.02),
            "tick_count": 80 + (index % 23),
            "bar_quality_status": "valid",
        }
    )


def test_preparation_and_features_are_chronological_without_target_leakage() -> None:
    """Preparation de-duplicates time and feature names exclude future targets."""

    source = synthetic_market_frame()
    duplicated = pd.concat([source.iloc[::-1], source.iloc[[10]]], ignore_index=True)
    prepared = prepare_data(duplicated)
    assert prepared["open_time_utc"].is_monotonic_increasing
    assert prepared["open_time_utc"].is_unique

    featured, columns = engineer_features(prepared, no_trade_threshold=0.00005)
    assert "target_return" not in columns
    assert "target_class" not in columns
    assert {"rsi_14", "atr_pct_14", "spread_pct"} <= set(columns)
    assert featured["target_class"].isin(["SELL", "NO_TRADE", "BUY"]).all()


def test_training_reports_all_requested_metrics_and_artifacts(tmp_path: Path) -> None:
    """A chronological test run produces F1, matrix, RMSE, MAE, and MSE."""

    prepared = prepare_data(synthetic_market_frame())
    featured, columns = engineer_features(prepared, no_trade_threshold=0.00005)
    split = chronological_split(featured, columns, train_fraction=0.75, horizon=1)
    assert split.train_times.max() < split.test_times.min()

    models = train_models(split, iterations=8, random_state=7)
    metrics, predictions, matrix = evaluate_models(models, split)
    assert {"f1_macro", "f1_weighted", "confusion_matrix"} <= set(metrics["classification"])
    assert {"rmse", "mae", "mse"} <= set(metrics["regression"])
    assert matrix.shape == (3, 3)
    assert len(predictions) == len(split.x_test)

    paths = save_artifacts(
        models,
        metrics,
        predictions,
        matrix,
        columns,
        {"test": True},
        output_dir=tmp_path,
    )
    assert set(paths) == {"model", "metrics", "predictions", "confusion_matrix"}
    assert all(path.exists() and path.stat().st_size > 0 for path in paths.values())


def test_price_forecast_becomes_spread_aware_signals_and_pnl(tmp_path: Path) -> None:
    """Price predictions produce checkpoints and price-unit P/L after spread."""

    history = pd.DataFrame(
        {
            "timestamp_utc": pd.date_range("2026-08-27", periods=3, freq="B", tz="UTC"),
            "close": [100.0, 101.0, 102.0],
        }
    )
    forecast = pd.DataFrame(
        {
            "timestamp_utc": pd.date_range("2026-09-01", periods=4, freq="B", tz="UTC"),
            "forecast_close": [103.0, 101.5, 101.55, 102.5],
        }
    )
    actual = pd.DataFrame(
        {
            "timestamp_utc": forecast["timestamp_utc"],
            "close": [102.8, 101.7, 101.8, 102.7],
        }
    )
    signals = derive_price_signals(history, forecast, spread_price=0.2)
    assert signals["signal"].tolist() == ["BUY", "SELL", "NO_TRADE", "BUY"]
    evaluated = evaluate_signal_outcomes(
        history,
        actual,
        signals,
        spread_price=0.2,
    )
    metrics = calculate_signal_metrics(
        actual,
        forecast,
        evaluated,
        spread_price=0.2,
    )
    assert metrics["signals"] == {"sell": 1, "no_trade": 1, "buy": 2}
    assert metrics["spread_accounting"]["unit"].startswith("XAUUSD price units")
    assert "realized_net_spreads_total_available" in metrics["spread_accounting"]
    assert metrics["classification"]["evaluated_observations"] == 4
    dashboard = create_signal_dashboard(
        history,
        actual,
        evaluated,
        metrics,
        tmp_path / "dashboard.html",
        forecast_start=pd.Timestamp("2026-09-01T00:00:00Z"),
    )
    assert dashboard.exists()
    assert dashboard.stat().st_size > 0


def test_spread_estimate_uses_only_trailing_history() -> None:
    """The spread estimate is a median of pre-forecast observations."""

    bars = pd.DataFrame(
        {
            "open_time_utc": pd.date_range("2026-08-01", periods=4, freq="7D", tz="UTC"),
            "spread_price": [100.0, 0.2, 0.4, 0.3],
        }
    )
    assert estimate_spread_price(bars, lookback_days=20) == 0.3
